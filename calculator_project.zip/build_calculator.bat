@echo off
echo Compiling calculator.cpp...
g++ calculator.cpp -o calculator.exe
if %errorlevel%==0 (
    echo Build successful! Run calculator.exe
) else (
    echo Compilation failed. Make sure MinGW or g++ is installed.
)
pause
