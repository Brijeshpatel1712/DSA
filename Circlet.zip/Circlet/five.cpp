#include <iostream>
using namespace std;

int main() {
    for(int i = 5; i >= 1; i--) {

        // Spaces
        for(int space = 1; space < i; space++) {
            cout << "  ";
        }

        // Increasing numbers
        for(int j = i; j <= 5; j++) {
            cout << j << " ";
        }

        // Decreasing numbers
        for(int j = 4; j >= i; j--) {
            cout << j << " ";
        }

        cout << endl;
    }
    return 0;
}