#include <iostream>
using namespace std;

int main() {
    char ch = 'a';

    do {
        cout << ch << " ";
        ch = ch + 4;   // skip 3 alphabets
    } while (ch <= 'z');

    return 0;
}
