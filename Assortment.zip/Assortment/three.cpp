#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the array's row & column size: ";
    cin >> n;

    int a[n][n];
    cout << "Enter array's elements:\n";
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            cout << "a[" << i << "][" << j << "] = ";
            cin >> a[i][j];
        }
    }

    cout << "\nThe transpose matrix of an array:\n";
    for(int j = 0; j < n; j++) {
        for(int i = 0; i < n; i++) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}