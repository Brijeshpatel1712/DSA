#include <iostream>
using namespace std;

int main() {
    int num, count = 0;

    cout << "Enter any number: ";
    cin >> num;

    if (num == 0) {
        count = 1;
    } else {
        while (num != 0) {
            count++;
            num /= 10;
        }
    }

    cout << "Total number of digits: " << count;
    return 0;
}
