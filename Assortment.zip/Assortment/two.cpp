#include <iostream>
using namespace std;

int main() {
    int r, c;
    cout << "Enter the array's row size: ";
    cin >> r;
    cout << "Enter the array's column size: ";
    cin >> c;

    int a[r][c];
    cout << "Enter array's elements:\n";
    for(int i = 0; i < r; i++) {
        for(int j = 0; j < c; j++) {
            cout << "a[" << i << "][" << j << "] = ";
            cin >> a[i][j];
        }
    }

    int max = a[0][0];
    for(int i = 0; i < r; i++) {
        for(int j = 0; j < c; j++) {
            if(a[i][j] > max) {
                max = a[i][j];
            }
        }
    }

    cout << "\nThe largest element is: " << max;

    return 0;
}