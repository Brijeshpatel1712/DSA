
#include <iostream>
using namespace std;

int add(int a, int b){ return a + b; }
int subtract(int a, int b){ return a - b; }
int multiply(int a, int b){ return a * b; }
float divide(int a, int b){ return (float)a / b; }
int modulus(int a, int b){ return a % b; }

int main()
{
    int choice, num1, num2;

    do
    {
        cout << "\nPress 1 for +" << endl;
        cout << "Press 2 for -" << endl;
        cout << "Press 3 for *" << endl;
        cout << "Press 4 for /" << endl;
        cout << "Press 5 for %" << endl;
        cout << "Press 0 for the exit" << endl;

        cout << "\nEnter your choice: ";
        cin >> choice;

        if(choice >= 1 && choice <= 5)
        {
            cout << "Enter the first number: ";
            cin >> num1;

            cout << "Enter the second number: ";
            cin >> num2;
        }

        switch(choice)
        {
            case 1:
                cout << "Addition of " << num1 << " and " << num2 << " is " << add(num1, num2) << endl;
                break;

            case 2:
                cout << "Subtraction of " << num1 << " and " << num2 << " is " << subtract(num1, num2) << endl;
                break;

            case 3:
                cout << "Multiplication of " << num1 << " and " << num2 << " is " << multiply(num1, num2) << endl;
                break;

            case 4:
                if(num2 != 0)
                    cout << "Division of " << num1 << " and " << num2 << " is " << divide(num1, num2) << endl;
                else
                    cout << "Division by zero is not allowed!" << endl;
                break;

            case 5:
                cout << "Modulus of " << num1 << " and " << num2 << " is " << modulus(num1, num2) << endl;
                break;

            case 0:
                cout << "Program exited." << endl;
                break;

            default:
                cout << "Invalid choice!" << endl;
        }

    } while(choice != 0);

    return 0;
}
