#include <iostream>
using namespace std;

int main() {
    int r, c;
    cout << "Enter the array's row size: ";
    cin >> r;
    cout << "Enter the array's column size: ";
    cin >> c;

    int a[r][c];
    cout << "Enter array's elements:\n";
    for(int i = 0; i < r; i++) {
        for(int j = 0; j < c; j++) {
            cout << "a[" << i << "][" << j << "] = ";
            cin >> a[i][j];
        }
    }

    int row;
    cout << "\nEnter row number: ";
    cin >> row;

    int rowSum = 0;
    cout << "Elements of row " << row << ": ";
    for(int j = 0; j < c; j++) {
        cout << a[row][j] << " ";
        rowSum += a[row][j];
    }
    cout << "\nThe sum of a row " << row << ": " << rowSum << endl;

    int col;
    cout << "\nEnter column number: ";
    cin >> col;

    int colSum = 0;
    cout << "Elements of column " << col << ": ";
    for(int i = 0; i < r; i++) {
        cout << a[i][col] << " ";
        colSum += a[i][col];
    }
    cout << "\nThe sum of column " << col << ": " << colSum;

    return 0;
}